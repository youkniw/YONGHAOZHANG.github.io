<p align="center"><img width="80%" src="./img/banner.png" /></a></p>

**<p align="center">📢纵有疾风起，人生不言弃 | Le vent se lève, il faut tenter de vivre🏃<p>**
<div>
    <img src="./img/githubavatar.jfif" alt="githubavatar" width="30%" align="right"/>
    
### 👋 关于我 | Player

- 🌏️某不知名大专大数据专业研一在读生一枚
- ⌨ 编程水货 🔜🧙图形学/视觉炼丹侠
- 💬 建立羁绊：1422257646@qq.com
- ⭐ 个人博客：🈺[coolchong.cn](https://coolchong.cn)
- 😋 杂食动物：🥤肥宅快乐水&&🎮️菜还爱玩&&🎸能谈响就行
</div>

### ⚒️ 技能树 | Stack

| 可能会的                                                     | 一知半解                                                     | 不懂装懂                                                     |
| ------------------------------------------------------------ | ------------------------------------------------------------ | ------------------------------------------------------------ |
| <code><img height="40" alt="cpp" src="./img/cpp.svg"></code> <code><img height="40" alt="python" src="./img/python.svg"></code> <code><img height="40" alt="java" src="./img/java.svg"></code> <code><img height="40" alt="js" src="./img/js.svg"></code> <code><img height="40" alt="vue" src="./img/vue.svg"></code> | <code><img height="40" alt="pytorch" src="./img/pytorch.svg"></code> <code><img height="40" alt="mysql" src="./img/mysql.svg"></code> <code><img height="40" alt="docker" src="./img/docker.svg"></code> <code><img height="40" alt="docker" src="./img/unity.svg"></code> <code><img height="40" alt="docker" src="./img/cs.svg"></code>| <code><img height="40" alt="linux" src="./img/linux.svg"></code> <code><img height="40" alt="cmake" src="./img/cmake.svg"></code> <code><img height="40" alt="matlab" src="./img/matlab.svg"></code> |

### 🧰 工具箱 | Tool

<code><img height="40" alt="vscode" src="./img/vscode.svg"></code>
<code><img height="40" alt="sublime" src="./img/sublime.svg"></code>
<code><img height="40" alt="pycharm" src="./img/pycharm.svg"></code>
<code><img height="40" alt="idea" src="./img/Idea.svg"></code>
<code><img height="40" alt="typora" src="./img/typora.svg"></code>
<code><img height="40" alt="github" src="./img/github.svg"></code>
<code><img height="40" alt="gitee" src="./img/gitee.svg"></code>
<code><img height="40" alt="wangzhe" src="./img/wangzhe.svg"></code>

### 🏆 数据板 | Record

![Langwenchong's GitHub stats](https://github-readme-stats.vercel.app/api?username=Langwenchong&count_private=true&show_icons=true&theme=flag-india&show_owner=true)
![pengpenglang's Most used languages](https://github-readme-stats.vercel.app/api/top-langs/?username=Langwenchong&layout=compact&hide_border=true&langs_count=10&hide=html)

